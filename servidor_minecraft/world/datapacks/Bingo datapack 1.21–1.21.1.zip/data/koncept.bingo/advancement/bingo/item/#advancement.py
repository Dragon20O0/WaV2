



f = '99.json'
ff = '99'

with open(f,'w') as t:
	t.write('{\n')
	t.write('	"credit": " Made by koncept",\n')
	t.write('    "criteria": {\n')
	t.write('        "1": {\n')
	t.write('            "trigger": "minecraft:inventory_changed",\n')
	t.write('            "conditions": {\n')
	t.write('                "items": [\n')
	t.write('                    {\n')
	t.write('                        "count": {\n')
	t.write('                            "min": 1,\n')
	t.write('                            "max": 64\n')
	t.write('                        },\n')
	t.write('                        "items": ["minecraft:')
	t.write(ff)
	t.write('"]\n')
	t.write('                    }\n')
	t.write('                ]\n')
	t.write('            }\n')
	t.write('        }\n')
	t.write('')
	t.write('    },\n')
	t.write('    "rewards": {\n')
	t.write('        "function": "koncept.bingo:bingo/advancement/')
	t.write(ff)	
	t.write('"\n')
	t.write('    }\n')
	t.write('}\n')
t.close()
print(ff)

